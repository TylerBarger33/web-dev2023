function changeStyle() {
    document.getElementById("pressingButton").style.fontSize = "32px"; 
    document.getElementById("pressingButton").style.color = "black";
    document.getElementById("pressingButton").style.backgroundColor = "orange"; 
    document.getElementById("pressingButton").style.borderBlockStyle = "solid";
    document.getElementById("pressingButton").style.borderBlockColor = "red";
    document.getElementById("pressingButton").style.borderBlockWidth = "10px";
    document.getElementById("pressingButton").style.padding = "10px";
    document.getElementById("pressingButton").textContent = "There and Back Again, a Tale by Bilbo Baggins."

}
function readBooks(){
   window.open('https://gosafir.com/mag/wp-content/uploads/2019/12/Tolkien-J.-The-lord-of-the-rings-HarperCollins-ebooks-2010.pdf', '_blank')
}